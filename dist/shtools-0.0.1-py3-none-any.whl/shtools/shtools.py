def test():
    """
    C'est une fonction de test ?
    -oui
    Il sert à quoi ?
    -Rien
    ok.
    """
    print("SWA Work")